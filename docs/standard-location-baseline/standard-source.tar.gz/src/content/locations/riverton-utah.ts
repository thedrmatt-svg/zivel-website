import type { Location } from "@/types/location";

export const zivel_riverton_location: Location = {
  name: "Zivel Riverton",
  county: "Salt Lake County",
  nearbyCommunities: ["South Jordan", "Herriman", "Bluffdale"],
  partnerApps: ["Wellhub"],
  slug: "riverton",
  state: "UT",
  stateSlug: "utah",
  citySlug: "riverton",

  openedYear: 2023,

  seo: {
    title: "Zivel Riverton",
    description: "Zivel Riverton offers cryotherapy, red light therapy, infrared sauna, dry float, and recovery services in Riverton, UT. Book your session today.",
    canonical: "https://www.zivel.com/locations/utah/riverton",
  },

  award: {
    image: "/images/locations/riverton/award.avif",
    headline: "Proud to be a 2026 Best of SLC Winner",
    body: "Thank you for supporting Zivel Riverton and trusting us with your recovery and wellness.",
  },

  contact: {
    address: "2722 W 12600 S #1, Riverton, UT 84065",
    phone: "(385) 443-8778",
    parking: "Free parking or street available",
    notes: "",
  },

  hours: {
    monday: "7am – 8pm",
    tuesday: "10am – 8pm",
    wednesday: "7am – 8pm",
    thursday: "10am – 8pm",
    friday: "8am – 8pm",
    saturday: "9am – 8pm",
    sunday: "10am – 2pm",
  },

  booking: {
    locationId: 11445,
  },

  services: [
  {
    "name": "Cryotherapy",
    "slug": "cryotherapy"
  },
  {
    "name": "Red Light Therapy",
    "slug": "red-light-therapy"
  },
  {
    "name": "Infrared Sauna",
    "slug": "infrared-sauna"
  },
  {
    "name": "Dry Float",
    "slug": "dry-float"
  },
  {
    "name": "Cryo Slimming",
    "slug": "cryo-slimming"
  },
  {
    "name": "Cryo Toning",
    "slug": "cryo-toning"
  },
  {
    "name": "CryoLift Facial",
    "slug": "cryo-lift-facial"
  },
  {
    "name": "Compression Therapy",
    "slug": "compression-therapy"
  },
  {
    "name": "Oxygen Bar",
    "slug": "oxygen-bar"
  },
  {
    "name": "Cryo Soothe",
    "slug": "cryo-soothe"
  }
],

  owners: [
  {
    "name": "Colin",
    "title": "Local Operator",
    "bio": "This location is independently operated. Local leadership supports the studio experience, community partnerships, and day-to-day service quality."
  }
],

  google: {
    placeId: "",
    mapEmbedUrl: "",
  },

  pricing: {
    membershipTiers: [
      {
        name: "Essential",
        price: "$99",
        cadence: "/mo",
        description: "A great entry point for regular recovery.",
        features: ["6 Recovery Sessions/Month", "Good for Beginners"],
        mostPopular: false,
      },
      {
        name: "Elite",
        price: "$175",
        cadence: "/mo",
        description: "More sessions, more value.",
        features: ["8 Recovery Sessions/Month", "Premium Service Discounts"],
        mostPopular: true,
      },
    ],
    standardPrices: [
      { name: "Cryotherapy", price: "$45", note: "Single session" },
      { name: "Red Light Therapy", price: "$30", note: "Single session" },
      { name: "Infrared Sauna", price: "$35", note: "Single session" },
      { name: "Dry Float", price: "$65", note: "Single session" },
      { name: "Compression Therapy", price: "$30", note: "Single session" },
      { name: "Oxygen Bar", price: "$30", note: "Single session" },
      { name: "Cryo Slimming", price: "$350", note: "Single session" },
      { name: "Cryo Slimming Series", price: "Contact store for pricing", note: "Series" },
      { name: "Cryo Toning", price: "$350", note: "Single session" },
      { name: "CryoLift Facial", price: "$150", note: "Single session" },
      { name: "Cryo Soothe", price: "$30", note: "Single session" },
    ],
  },

  partners: [
    {
      name: "Partner Name",
      type: "Chiropractic / Gym / etc",
      description: "2-3 sentences placeholder about the partnership.",
      website: "https://example.com",
      logo: "/images/partners/example.png",
    },
  ],

  jobs: [
    {
      title: "Wellness Specialist",
      type: "Part-time",
      locationNote: "On-site",
      description: "Placeholder role summary.",
      applyUrl: "https://example.com/apply",
    },
  ],

  store: [
    {
      name: "Product Name",
      description: "Placeholder product description.",
      image: "/images/store/placeholder.png",
      price: "$X",
      url: "https://example.com/shop",
    },
  ],

  localBlog: {
    href: "/locations/utah/riverton/blog",
    heading: "Riverton Wellness Insights",
    description:
      "Stay up to date with the latest recovery tips, local wellness news, client stories, and expert advice from the Zivel Riverton team. Discover how cryotherapy, red light therapy, infrared sauna, and more are helping people in Riverton and along the Wasatch Front feel and perform their best.",
    ctaLabel: "Read the Riverton Blog",
  },
};

export default zivel_riverton_location;
