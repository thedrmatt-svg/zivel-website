import type { Location } from "@/types/location";

export const zivel_briargate_location: Location = {
  name: "Zivel Briargate",
  county: "El Paso County",
  nearbyCommunities: ["Monument", "Black Forest", "the Air Force Academy area"],
  partnerApps: ["Wellhub", "ClassPass"],
  slug: "briargate",
  city: "Colorado Springs",
  state: "CO",
  stateSlug: "colorado",
  citySlug: "briargate",
  openedYear: 2026,

  seo: {
    title: "Zivel Briargate",
    description: "Zivel Briargate offers cryotherapy, red light therapy, infrared sauna, dry float, and recovery services in Colorado Springs, CO. Book your session today.",
    canonical: "https://www.zivel.com/locations/colorado/briargate",
  },

  contact: {
    address: "460 Chapel Hills Dr Ste 120, Colorado Springs, CO 80920",
    phone: "(719) 500-1638",
    parking: "Free parking or street available",
    notes: "",
    email: "zivelbriargate@gmail.com",
  },

  hours: {
    monday: "8:30am – 6:30pm",
    tuesday: "8:30am – 6:30pm",
    wednesday: "8:30am – 6:30pm",
    thursday: "8:30am – 6:30pm",
    friday: "8:30am – 6:30pm",
    saturday: "9am – 4pm",
    sunday: "Closed",
  },

  booking: {
    locationId: 11779,
  },

  services: [
  {
    "name": "Cryotherapy",
    "slug": "cryotherapy"
  },
  {
    "name": "Red Light Therapy",
    "slug": "red-light-therapy"
  },
  {
    "name": "Infrared Sauna",
    "slug": "infrared-sauna"
  },
  {
    "name": "Cryo Slimming",
    "slug": "cryo-slimming"
  },
  {
    "name": "Cryo Toning",
    "slug": "cryo-toning"
  },
  {
    "name": "CryoLift Facial",
    "slug": "cryo-lift-facial"
  },
  {
    "name": "Compression Therapy",
    "slug": "compression-therapy"
  },
  {
    "name": "Cryo Soothe",
    "slug": "cryo-soothe"
  }
],

  owners: [
  {
    "name": "Gracie",
    "title": "Local Operator",
    "bio": "This location is independently operated. Local leadership supports the studio experience, community partnerships, and day-to-day service quality."
  }
],

  google: {
    placeId: "ChIJFdsggG9NE4cR0dKogMxsgbI",
    mapEmbedUrl: "",
  },

  pricing: {
    membershipTiers: [
      {
        name: "Essential",
        price: "$99",
        cadence: "/mo",
        description: "A great entry point for regular recovery.",
        features: ["8 Recovery services per month", "Good for Beginners"],
        mostPopular: false,
      },
      {
        name: "Elite",
        price: "$150",
        cadence: "/mo",
        description: "More sessions, more value.",
        features: ["12 Recovery Sessions/Month", "Premium Service Discounts"],
        mostPopular: true,
      },
    ],
    standardPrices: [
      { name: "Cryotherapy", price: "$37", note: "Single session" },
      { name: "Red Light Therapy", price: "$37", note: "Single session" },
      { name: "Infrared Sauna", price: "$37", note: "Single session" },
      { name: "Compression Therapy", price: "$37", note: "Single session" },
      { name: "Cryo Slimming", price: "$350", note: "Single session" },
      { name: "Cryo Toning", price: "$350", note: "Single session" },
      { name: "CryoLift Facial", price: "$150", note: "Single session" },
      { name: "Cryo Soothe", price: "$37", note: "Single session" },
    ],
  },

  partners: [
    {
      name: "Partner Name",
      type: "Chiropractic / Gym / etc",
      description: "2-3 sentences placeholder about the partnership.",
      website: "https://example.com",
      logo: "/images/partners/example.png",
    },
  ],

  jobs: [
    {
      title: "Wellness Specialist",
      type: "Part-time",
      locationNote: "On-site",
      description: "Placeholder role summary.",
      applyUrl: "https://example.com/apply",
    },
  ],

  store: [
    {
      name: "Product Name",
      description: "Placeholder product description.",
      image: "/images/store/placeholder.png",
      price: "$X",
      url: "https://example.com/shop",
    },
  ],

  localBlog: {
    href: "/locations/colorado/briargate/blog",
    heading: "Briargate Wellness Insights",
    description:
      "Stay up to date with the latest recovery tips, local wellness news, client stories, and expert advice from the Zivel Briargate team. Discover how cryotherapy, red light therapy, infrared sauna, and more are helping people in Colorado Springs and the Briargate area feel and perform their best.",
    ctaLabel: "Read the Briargate Blog",
  },
};

export default zivel_briargate_location;
