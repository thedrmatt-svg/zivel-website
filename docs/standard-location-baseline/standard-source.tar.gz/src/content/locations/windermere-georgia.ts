import type { Location } from "@/types/location";

export const zivel_cumming_windermere_location: Location = {
  name: "Zivel Windermere",
  county: "Forsyth County",
  nearbyCommunities: ["Alpharetta", "Johns Creek", "Cumming"],
  slug: "windermere",
  state: "GA",
  stateSlug: "georgia",
  citySlug: "windermere",
  openedYear: 2025,
  updatedAt: "2026-07-08",

  seo: {
    title: "Zivel Windermere",
    description: "Zivel Windermere offers cryotherapy, red light therapy, infrared sauna, dry float, and recovery services in Cumming, GA. Book your session today.",
    canonical: "https://www.zivel.com/locations/georgia/windermere",
  },

  contact: {
    address: "3775 Windermere Pkwy suite l, Cumming, GA 30041",
    phone: "(470) 539-1126",
    parking: "Free parking or street available",
    notes: "",
  },

  hours: {
    monday: "9am – 7pm",
    tuesday: "9am – 7pm",
    wednesday: "9am – 7pm",
    thursday: "9am – 7pm",
    friday: "9am – 5pm",
    saturday: "9am – 5pm",
    sunday: "Closed",
  },

  booking: {
    locationId: 11617,
  },

  services: [
  {
    "name": "Cryotherapy",
    "slug": "cryotherapy"
  },
  {
    "name": "Red Light Therapy",
    "slug": "red-light-therapy"
  },
  {
    "name": "Infrared Sauna",
    "slug": "infrared-sauna"
  },
  {
    "name": "Dry Float",
    "slug": "dry-float"
  },
  {
    "name": "Cryo Slimming",
    "slug": "cryo-slimming"
  },
  {
    "name": "Cryo Toning",
    "slug": "cryo-toning"
  },
  {
    "name": "CryoLift Facial",
    "slug": "cryo-lift-facial"
  },
  {
    "name": "Compression Therapy",
    "slug": "compression-therapy"
  },
  {
    "name": "Oxygen Bar",
    "slug": "oxygen-bar"
  },
  {
    "name": "Cryo Soothe",
    "slug": "cryo-soothe"
  }
],

  owners: [
  {
    "name": "Janis",
    "title": "Local Operator",
    "bio": "This location is independently operated. Local leadership supports the studio experience, community partnerships, and day-to-day service quality."
  }
],

  google: {
    placeId: "",
    mapEmbedUrl: "",
  },

  pricing: {
    pricingUpdatedAt: "2026-07-08",
    membershipTiers: [
      {
        name: "Individual Unlimited Plan",
        price: "$99",
        cadence: "1st month",
        description: "Then $179/mo from month 2.",
        features: ["Unlimited Recovery Services", "All Locations Access"],
        mostPopular: true,
        bookingUrl: "https://app.clubready.com/JoinUs/14944/637624",
      },
      {
        name: "Essential",
        price: "$99",
        cadence: "/mo",
        description: "A great entry point for regular recovery.",
        features: ["6 Recovery Sessions/Month", "Good for Beginners"],
        mostPopular: false,
        bookingUrl: "https://app.clubready.com/JoinUs/14944/630695",
      },
      {
        name: "Elite",
        price: "$129",
        cadence: "/mo",
        description: "More sessions, more value.",
        features: ["8 Recovery Sessions/Month", "Premium Service Discounts"],
        mostPopular: false,
        bookingUrl: "https://app.clubready.com/JoinUs/14944/630696",
      },
      {
        name: "Family Unlimited",
        price: "$189",
        cadence: "1st month",
        description: "Then $299/mo from month 2.",
        features: [
          "Unlimited Recovery Services for up to 4 family members",
          "Discounts on Premium Services",
        ],
        mostPopular: false,
        bookingUrl: "https://app.clubready.com/JoinUs/14944/637626",
      },
    ],
    specialDealsBottomInlinePricing: true,
    specialDealsBottomPremiumStart: 1,
    specialDealsBottom: [
      {
        name: "Day Pass — 3 Recovery Sessions",
        price: "$49",
        savings: "Completed in 1 day",
        benefits: ["First Time Clients Only", "Single use"],
        bookingUrl: "https://app.clubready.com/JoinUs/14944/641756",
      },
      {
        name: "5 Cryo Facials",
        price: "$700",
        regularPrice: "$750",
        showLimitedTimeBadge: false,
        description: "Five targeted CryoLift Facial sessions to support smoother-looking skin, firmness, and a refreshed appearance.",
        bookingUrl: "https://app.clubready.com/JoinUs/14944/627875",
      },
      {
        name: "5 Cryo Slimmings/Tonings",
        price: "$1,600",
        regularPrice: "$1,750",
        showLimitedTimeBadge: false,
        description: "Sculpt and contour your body with five precision Cryo Slimming or Toning treatments.",
        bookingUrl: "https://app.clubready.com/JoinUs/14944/627871",
      },
      {
        name: "10 Cryo Slimmings/Tonings",
        price: "$3,150",
        regularPrice: "$3,500",
        showLimitedTimeBadge: false,
        description: "Our best value — ten Cryo Slimming or Toning sessions for maximum, lasting results.",
        bookingUrl: "https://app.clubready.com/JoinUs/14944/627872",
      },
    ],
    giftCards: [
      { amount: "$50", purchaseUrl: "https://app.clubready.com/JoinUs/14944/644563" },
      { amount: "$100", purchaseUrl: "https://app.clubready.com/JoinUs/14944/644566" },
      { amount: "$200", purchaseUrl: "https://app.clubready.com/JoinUs/14944/644567" },
    ],
    standardPrices: [
      { name: "Cryotherapy", price: "$40", note: "Single session" },
      { name: "Red Light Therapy", price: "$30", note: "Single session" },
      { name: "Infrared Sauna", price: "$40", note: "Single session" },
      { name: "Dry Float", price: "$65", note: "Single session" },
      { name: "Compression Therapy", price: "$30", note: "Single session" },
      { name: "Oxygen Bar", price: "$30", note: "Single session" },
      { name: "Cryo Slimming", price: "$350", note: "Single session" },
      { name: "Cryo Toning", price: "$350", note: "Single session" },
      { name: "CryoLift Facial", price: "$150", note: "Single session" },
      { name: "Cryo Soothe", price: "$40", note: "Single session" },
    ],
    membershipTerms:
      "Memberships renew monthly. Cancel with written 30 day notice after 3 month minimum. Contact the studio for terms.",
  },

  partners: [
    {
      name: "Partner Name",
      type: "Chiropractic / Gym / etc",
      description: "2-3 sentences placeholder about the partnership.",
      website: "https://example.com",
      logo: "/images/partners/example.png",
    },
  ],

  jobs: [
    {
      title: "Wellness Specialist",
      type: "Part-time",
      locationNote: "On-site",
      description: "Placeholder role summary.",
      applyUrl: "https://example.com/apply",
    },
  ],

  store: [
    {
      name: "Product Name",
      description: "Placeholder product description.",
      image: "/images/store/placeholder.png",
      price: "$X",
      url: "https://example.com/shop",
    },
  ],

  localBlog: {
    href: "/locations/georgia/windermere/blog",
    heading: "Windermere Wellness Insights",
    description:
      "Stay up to date with the latest recovery tips, local wellness news, client stories, and expert advice from the Zivel Windermere team. Discover how cryotherapy, red light therapy, infrared sauna, and more are helping people in Cumming, Forsyth County, and North Atlanta feel and perform their best.",
    ctaLabel: "Read the Windermere Blog",
  },
};

export default zivel_cumming_windermere_location;
