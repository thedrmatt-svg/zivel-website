import type { Location } from "@/types/location";

export const zivel_hollywood_location: Location = {
  name: "Zivel Hollywood",
  county: "Broward County",
  nearbyCommunities: ["Hallandale Beach", "Dania Beach", "Pembroke Pines", "Miramar"],
  slug: "hollywood",
  state: "FL",
  stateSlug: "florida",
  citySlug: "hollywood",
  openedYear: 2025,

  seo: {
    title: "Zivel Hollywood",
    description: "Zivel Hollywood offers cryotherapy, red light therapy, infrared sauna, dry float, and recovery services in Hollywood, FL. Book your session today.",
    canonical: "https://www.zivel.com/locations/florida/hollywood",
  },

  contact: {
    address: "3361 Sheridan St, Hollywood, FL 33021",
    phone: "(754) 217-8177",
    parking: "Free parking or street available",
    notes: "",
  },

  hours: {
    monday: "9am – 7pm",
    tuesday: "9am – 7pm",
    wednesday: "9am – 7pm",
    thursday: "9am – 7pm",
    friday: "9am – 5pm",
    saturday: "9am – 4pm",
    sunday: "9am – 1pm",
  },

  booking: {
    locationId: 11433,
  },

  services: [
  {
    "name": "Cryotherapy",
    "slug": "cryotherapy"
  },
  {
    "name": "Red Light Therapy",
    "slug": "red-light-therapy"
  },
  {
    "name": "Infrared Sauna",
    "slug": "infrared-sauna"
  },
  {
    "name": "Dry Float",
    "slug": "dry-float"
  },
  {
    "name": "Cryo Slimming",
    "slug": "cryo-slimming"
  },
  {
    "name": "Cryo Toning",
    "slug": "cryo-toning"
  },
  {
    "name": "CryoLift Facial",
    "slug": "cryo-lift-facial"
  },
  {
    "name": "Compression Therapy",
    "slug": "compression-therapy"
  },
  {
    "name": "Oxygen Bar",
    "slug": "oxygen-bar"
  },
  {
    "name": "Cryo Soothe",
    "slug": "cryo-soothe"
  }
],

  owners: [
  {
    "name": "Peter & Michelle",
    "title": "Local Operator",
    "bio": "This location is independently operated. Local leadership supports the studio experience, community partnerships, and day-to-day service quality."
  }
],

  google: {
    placeId: "",
    mapEmbedUrl: "",
  },

  pricing: {
    specialDealsBottomInlinePricing: true,
    specialDealsBottomPremiumStart: 0,
    specialDealsBottom: [
      {
        name: "5 Cryo Facials",
        price: "$625",
        regularPrice: "$750",
        description: "Rejuvenate and tighten skin with five targeted CryoLift Facial sessions.",
        image: "/images/services/cryo-lift-facial/intro.avif",
        bookingUrl: "https://app.clubready.com/JoinUs/14829/632488",
      },
      {
        name: "5 Cryo Slimmings",
        price: "$1,400",
        regularPrice: "$1,750",
        description: "Sculpt and contour your body with five precision Cryo Slimming treatments.",
        image: "/images/services/cryo-slimming/intro.avif",
        bookingUrl: "https://app.clubready.com/JoinUs/14829/632490",
      },
      {
        name: "10 Cryo Slimmings",
        price: "$2,500",
        regularPrice: "$3,500",
        description: "Our best value — ten Cryo Slimming sessions for maximum, lasting results.",
        image: "/images/services/cryo-slimming/hero.avif",
        bookingUrl: "https://app.clubready.com/JoinUs/14829/632491",
      },
    ],
    membershipTiers: [
      {
        name: "Essential",
        price: "$99",
        cadence: "/mo",
        description: "A great entry point for regular recovery.",
        features: ["8 Recovery Sessions/Month", "Good for Beginners"],
        mostPopular: false,
        bookingUrl: "https://app.clubready.com/JoinUs/14829/638721",
      },
      {
        name: "Elite",
        price: "$129",
        cadence: "/mo",
        description: "More sessions, more value.",
        features: ["12 Recovery Sessions/Month", "Premium Service Discounts"],
        mostPopular: true,
        bookingUrl: "https://app.clubready.com/JoinUs/14829/638726",
      },
    ],
    standardPrices: [
      { name: "Cryotherapy", price: "$45", note: "Single session" },
      { name: "Red Light Therapy", price: "$45", note: "Single session" },
      { name: "Infrared Sauna", price: "$45", note: "Single session" },
      { name: "Dry Float", price: "$60", note: "Single session" },
      { name: "Compression Therapy", price: "$45", note: "Single session" },
      { name: "Oxygen Bar", price: "$30", note: "Single session" },
      { name: "Cryo Slimming", price: "$350", note: "Single session" },
      { name: "Cryo Toning", price: "$350", note: "Single session" },
      { name: "CryoLift Facial", price: "$175", note: "Single session" },
      { name: "Cryo Soothe", price: "$50", note: "Single session" },
    ],
  },

  partners: [
    {
      name: "Partner Name",
      type: "Chiropractic / Gym / etc",
      description: "2-3 sentences placeholder about the partnership.",
      website: "https://example.com",
      logo: "/images/partners/example.png",
    },
  ],

  jobs: [
    {
      title: "Wellness Specialist",
      type: "Part-time",
      locationNote: "On-site",
      description: "Placeholder role summary.",
      applyUrl: "https://example.com/apply",
    },
  ],

  store: [
    {
      name: "Product Name",
      description: "Placeholder product description.",
      image: "/images/store/placeholder.png",
      price: "$X",
      url: "https://example.com/shop",
    },
  ],

  localBlog: {
    href: "/locations/florida/hollywood/blog",
    heading: "Hollywood Wellness Insights",
    description:
      "Stay up to date with the latest recovery tips, local wellness news, client stories, and expert advice from the Zivel Hollywood team. Discover how cryotherapy, red light therapy, infrared sauna, and more are helping people in Hollywood and Broward County feel and perform their best.",
    ctaLabel: "Read the Hollywood Blog",
  },
};

export default zivel_hollywood_location;
