import type { Location } from "@/types/location";

export const zivel_parker_location: Location = {
  name: "Zivel Parker",
  county: "Douglas County",
  nearbyCommunities: ["Lone Tree", "Aurora", "Castle Rock"],
  siteName: "Crossing at Stonegate",
  slug: "parker",
  state: "CO",
  stateSlug: "colorado",
  citySlug: "parker",
  openedYear: 2026,

  seo: {
    title: "Zivel Parker",
    description: "Zivel Parker offers cryotherapy, red light therapy, infrared sauna, dry float, and recovery services in Parker, CO. Book your session today.",
    canonical: "https://www.zivel.com/locations/colorado/parker",
  },

  contact: {
    address: "17021 Lincoln Ave ste c, Parker, CO 80134",
    phone: "(720) 366-3622",
    parking: "Free parking or street available",
    notes: "",
  },

  hours: {
    monday: "11am – 7pm",
    tuesday: "9am – 7pm",
    wednesday: "9am – 7pm",
    thursday: "9am – 7pm",
    friday: "9am – 6pm",
    saturday: "9am – 4pm",
    sunday: "10am – 2pm",
  },

  booking: {
    locationId: 11680,
  },

  services: [
  {
    "name": "Cryotherapy",
    "slug": "cryotherapy"
  },
  {
    "name": "Red Light Therapy",
    "slug": "red-light-therapy"
  },
  {
    "name": "Infrared Sauna",
    "slug": "infrared-sauna"
  },
  {
    "name": "Dry Float",
    "slug": "dry-float"
  },
  {
    "name": "Cryo Slimming",
    "slug": "cryo-slimming"
  },
  {
    "name": "Cryo Toning",
    "slug": "cryo-toning"
  },
  {
    "name": "CryoLift Facial",
    "slug": "cryo-lift-facial"
  },
  {
    "name": "Compression Therapy",
    "slug": "compression-therapy"
  },
  {
    "name": "Oxygen Bar",
    "slug": "oxygen-bar"
  },
  {
    "name": "Cryo Soothe",
    "slug": "cryo-soothe"
  }
],

  owners: [
  {
    "name": "Carla",
    "title": "Local Operator",
    "bio": "This location is independently operated. Local leadership supports the studio experience, community partnerships, and day-to-day service quality."
  }
],

  google: {
    placeId: "",
    mapEmbedUrl: "",
  },

  pricing: {
    membershipTiers: [
      {
        name: "Essential",
        price: "$119",
        cadence: "/mo",
        description: "A great entry point for regular recovery.",
        features: ["4 Recovery visits/month", "8 total Recovery Sessions", "Good for Beginners"],
        mostPopular: false,
      },
      {
        name: "Elite",
        price: "$159",
        cadence: "/mo",
        description: "More sessions, more value.",
        features: ["8 Recovery visits/month", "16 total Recovery Sessions", "Premium Service Discounts"],
        mostPopular: true,
      },
    ],
    standardPrices: [
      { name: "Cryotherapy", price: "$45", note: "Single session" },
      { name: "Red Light Therapy", price: "$50", note: "Single session" },
      { name: "Infrared Sauna", price: "$50", note: "Single session" },
      { name: "Dry Float", price: "$50", note: "Single session" },
      { name: "Compression Therapy", price: "$30", note: "Single session" },
      { name: "Oxygen Bar", price: "$20", note: "Single session" },
      { name: "Cryo Slimming", price: "$350", note: "Single session" },
      { name: "Cryo Toning", price: "$350", note: "Single session" },
      { name: "CryoLift Facial", price: "$179", note: "Single session" },
      { name: "Cryo Soothe", price: "$50", note: "Single session" },
    ],
  },

  partners: [
    {
      name: "Partner Name",
      type: "Chiropractic / Gym / etc",
      description: "2-3 sentences placeholder about the partnership.",
      website: "https://example.com",
      logo: "/images/partners/example.png",
    },
  ],

  jobs: [
    {
      title: "Wellness Specialist",
      type: "Part-time",
      locationNote: "On-site",
      description: "Placeholder role summary.",
      applyUrl: "https://example.com/apply",
    },
  ],

  store: [
    {
      name: "Product Name",
      description: "Placeholder product description.",
      image: "/images/store/placeholder.png",
      price: "$X",
      url: "https://example.com/shop",
    },
  ],

  localBlog: {
    href: "/locations/colorado/parker/blog",
    heading: "Parker Wellness Insights",
    description:
      "Stay up to date with the latest recovery tips, local wellness news, client stories, and expert advice from the Zivel Parker team. Discover how cryotherapy, red light therapy, infrared sauna, and more are helping people in Parker and the South Denver area feel and perform their best.",
    ctaLabel: "Read the Parker Blog",
  },
};

export default zivel_parker_location;
