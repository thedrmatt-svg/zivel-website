import type { Location } from "@/types/location";

export const zivel_metairie_location: Location = {
  name: "Zivel Metairie",
  county: "Jefferson Parish",
  nearbyCommunities: ["New Orleans", "Kenner", "Harahan"],
  slug: "metairie",
  state: "LA",
  stateSlug: "louisiana",
  citySlug: "metairie",
  openedYear: 2025,

  seo: {
    title: "Zivel Metairie",
    description: "Zivel Metairie offers cryotherapy, red light therapy, infrared sauna, dry float, and recovery services in Metairie, LA. Book your session today.",
    canonical: "https://www.zivel.com/locations/louisiana/metairie",
  },

  contact: {
    address: "701 Metairie Rd suite 1b 201, Metairie, LA 70005",
    phone: "(504) 519-7154",
    parking: "Free parking or street available",
    notes: "",
  },

  hours: {
    monday: "9am – 7pm",
    tuesday: "9am – 7pm",
    wednesday: "9am – 7pm",
    thursday: "9am – 7pm",
    friday: "9am – 7pm",
    saturday: "10am – 5pm",
    sunday: "12pm – 4pm",
  },

  booking: {
    locationId: 11435,
  },

  services: [
  {
    "name": "Cryotherapy",
    "slug": "cryotherapy"
  },
  {
    "name": "Red Light Therapy",
    "slug": "red-light-therapy"
  },
  {
    "name": "Infrared Sauna",
    "slug": "infrared-sauna"
  },
  {
    "name": "Dry Float",
    "slug": "dry-float"
  },
  {
    "name": "Cryo Slimming",
    "slug": "cryo-slimming"
  },
  {
    "name": "Cryo Toning",
    "slug": "cryo-toning"
  },
  {
    "name": "CryoLift Facial",
    "slug": "cryo-lift-facial"
  },
  {
    "name": "Compression Therapy",
    "slug": "compression-therapy"
  },
  {
    "name": "Oxygen Bar",
    "slug": "oxygen-bar"
  },
  {
    "name": "Cryo Soothe",
    "slug": "cryo-soothe"
  }
],

  owners: [
  {
    "name": "Chris, Trey & Josh",
    "title": "Local Operator",
    "bio": "This location is independently operated. Local leadership supports the studio experience, community partnerships, and day-to-day service quality."
  }
],

  google: {
    placeId: "",
    mapEmbedUrl: "",
  },

  pricing: {
    membershipTiers: [
      {
        name: "Essential",
        price: "$99",
        cadence: "/mo",
        description: "A great entry point for regular recovery.",
        features: ["4 Recovery Sessions/Month", "Good for Beginners"],
        mostPopular: false,
      },
      {
        name: "Gold",
        price: "$139",
        cadence: "/mo",
        description: "More sessions, more value.",
        features: ["8 Recovery Sessions/Month", "Premium Service Discounts"],
        mostPopular: true,
      },
      {
        name: "Elite",
        price: "$199",
        cadence: "/mo",
        description: "The complete Zivel experience.",
        features: ["Unlimited Recovery Services", "Discounts on Premium Services"],
        mostPopular: false,
      },
    ],
    standardPrices: [
      { name: "Cryotherapy", price: "$40", note: "Single session" },
      { name: "Red Light Therapy", price: "$35", note: "Single session" },
      { name: "Infrared Sauna", price: "$35", note: "Single session" },
      { name: "Dry Float", price: "$40", note: "Single session" },
      { name: "Compression Therapy", price: "$35", note: "Single session" },
      { name: "Cryo Slimming", price: "$350", note: "Single session" },
      { name: "Cryo Toning", price: "$300", note: "Single session" },
      { name: "CryoLift Facial", price: "$200", note: "Single session" },
      { name: "Cryo Soothe", price: "$100", note: "Single session" },
    ],
  },

  partners: [
    {
      name: "Partner Name",
      type: "Chiropractic / Gym / etc",
      description: "2-3 sentences placeholder about the partnership.",
      website: "https://example.com",
      logo: "/images/partners/example.png",
    },
  ],

  jobs: [
    {
      title: "Wellness Specialist",
      type: "Part-time",
      locationNote: "On-site",
      description: "Placeholder role summary.",
      applyUrl: "https://example.com/apply",
    },
  ],

  store: [
    {
      name: "Product Name",
      description: "Placeholder product description.",
      image: "/images/store/placeholder.png",
      price: "$X",
      url: "https://example.com/shop",
    },
  ],

  localBlog: {
    href: "/locations/louisiana/metairie/blog",
    heading: "Metairie Wellness Insights",
    description:
      "Stay up to date with the latest recovery tips, local wellness news, client stories, and expert advice from the Zivel Metairie team. Discover how cryotherapy, red light therapy, infrared sauna, and more are helping people in Metairie and Greater New Orleans feel and perform their best.",
    ctaLabel: "Read the Metairie Blog",
  },
};

export default zivel_metairie_location;
