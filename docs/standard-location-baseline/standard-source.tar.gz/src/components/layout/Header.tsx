"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useMemo, useState, useEffect, useRef, type MouseEvent } from "react";
import { services } from "@/lib/data/services";
import { pathways } from "@/lib/data/pathways";
import type { getLocationNav } from "@/lib/data/locationNav";
import { isBrecksvilleLocationPath } from "@/lib/location-availability";
import { getHeaderBookingAction, type LocationBookingActions } from "@/lib/location-booking";


export default function Header({
  locationNav: LOCATIONS_NAV,
  bookingActions,
  pathnameOverride,
}: {
  locationNav: ReturnType<typeof getLocationNav>;
  bookingActions: LocationBookingActions;
  /** Let an isolated preview display the source page's navigation and booking action. */
  pathnameOverride?: string;
}) {
  const currentPathname = usePathname();
  const pathname = pathnameOverride ?? currentPathname;
  const bookingAction = getHeaderBookingAction(pathname, bookingActions);
  const isBrecksville = isBrecksvilleLocationPath(pathname);
  const bookingDisabled = isBrecksville;
  const [mobileOpen, setMobileOpen] = useState(false);
  const [mobileServicesOpen, setMobileServicesOpen] = useState(false);
  const [mobileLocationsOpen, setMobileLocationsOpen] = useState(false);
  const [desktopLocationsDismissed, setDesktopLocationsDismissed] = useState(false);
  const [mobilePathwaysOpen, setMobilePathwaysOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const menuToggleRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Task #35 — Escape key closes the mobile menu and returns focus to the toggle button
  useEffect(() => {
    if (!mobileOpen) return;
    function handleKeyDown(e: KeyboardEvent) {
      if (e.key !== "Escape") return;
      setMobileOpen(false);
      setMobileServicesOpen(false);
      setMobilePathwaysOpen(false);
      setMobileLocationsOpen(false);
      menuToggleRef.current?.focus();
    }
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [mobileOpen]);

  const serviceLinks = useMemo(
    () =>
      services.filter((s) => !isBrecksville || s.slug !== "red-light-therapy").map((s) => ({
        label: s.name,
        href: `/services/${s.slug}`,
        description: s.hero.subheadline,
      })),
    [isBrecksville]
  );

  const pathwayLinks = useMemo(
    () =>
      pathways.map((p) => ({
        label: p.name,
        href: `/pathways/${p.slug}`,
        description: isBrecksville && p.slug === "skin-health-regenerative-aesthetics"
          ? "A wellness pathway supporting skin health, firmness, and appearance with non-invasive aesthetic services."
          : p.seo.description,
      })),
    [isBrecksville]
  );

  const isActive = (href: string) =>
    pathname === href || (href !== "/" && pathname?.startsWith(href));

  const closeDesktopLocations = (event: MouseEvent<HTMLElement>) => {
    setDesktopLocationsDismissed(true);
    event.currentTarget.blur();
  };

  const navLinkClass =
    "text-[13px] font-medium tracking-wide uppercase text-white/70 hover:text-[var(--zivel-gold)] transition-colors duration-300";

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-black/90 backdrop-blur-xl border-b border-white/[0.06] py-0"
          : "bg-transparent py-2"
      }`}
    >
      <div className="mx-auto max-w-7xl px-6">
        <div className="flex h-16 md:h-20 items-center justify-between gap-4">
          <Link href="/" className="flex items-center pl-1 md:pl-2" aria-label="Zivel Home">
            <Image
              src="/images/brand/zivel-logo.png"
              alt="Zivel"
              width={1499}
              height={573}
              priority
              fetchPriority="high"
              className="!h-9 md:!h-10 lg:!h-12 xl:!h-14 !w-auto transition-all duration-200"
            />
          </Link>

          <nav aria-label="Primary navigation" className="hidden items-center gap-8 lg:flex">
            <div className="relative group">
              <Link
                href="/services"
                className={`${navLinkClass} ${isActive("/services") ? "text-[var(--zivel-gold)]" : ""}`}
              >
                Services
              </Link>

              <div className="invisible absolute left-1/2 -translate-x-1/2 top-full pt-4 opacity-0 transition-all duration-300 group-hover:visible group-hover:opacity-100 group-focus-within:visible group-focus-within:opacity-100">
                <div className="w-[360px] rounded-xl border border-white/10 bg-black/95 backdrop-blur-xl p-3 shadow-[0_20px_60px_rgba(0,0,0,0.8)]">
                  <Link
                    href="/services"
                    className="block rounded-lg px-3 py-3 text-sm font-semibold text-white hover:bg-white/5 transition-colors"
                  >
                    View All Services →
                  </Link>
                  <div className="my-2 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
                  <div className="max-h-[360px] overflow-auto pr-1">
                    {serviceLinks.map((item) => (
                      <Link
                        key={item.href}
                        href={item.href}
                        className="block rounded-lg px-3 py-3 hover:bg-white/5 transition-colors"
                      >
                        <div className="text-sm font-semibold text-white">{item.label}</div>
                        <div className="mt-1 text-xs text-white/50">{item.description}</div>
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="relative group">
              <Link
                href="/pathways"
                className={`${navLinkClass} ${isActive("/pathways") ? "text-[var(--zivel-gold)]" : ""}`}
              >
                Pathways
              </Link>

              <div className="invisible absolute left-1/2 -translate-x-1/2 top-full pt-4 opacity-0 transition-all duration-300 group-hover:visible group-hover:opacity-100 group-focus-within:visible group-focus-within:opacity-100">
                <div className="w-[420px] rounded-xl border border-white/10 bg-black/95 backdrop-blur-xl p-3 shadow-[0_20px_60px_rgba(0,0,0,0.8)]">
                  <Link
                    href="/pathways"
                    className="block rounded-lg px-3 py-3 text-sm font-semibold text-white hover:bg-white/5 transition-colors"
                  >
                    View All Pathways →
                  </Link>
                  <div className="my-2 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
                  <div className="max-h-[400px] overflow-auto pr-1">
                    {pathwayLinks.map((item) => (
                      <Link
                        key={item.href}
                        href={item.href}
                        className="block rounded-lg px-3 py-3 hover:bg-white/5 transition-colors"
                      >
                        <div className="text-sm font-semibold text-white">{item.label}</div>
                        <div className="mt-1 text-xs text-white/50 line-clamp-2">{item.description}</div>
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div
              className="relative group"
              onMouseLeave={() => setDesktopLocationsDismissed(false)}
            >
              <Link
                href="/locations"
                className={`${navLinkClass} inline-flex items-center gap-1 ${isActive("/locations") ? "text-[var(--zivel-gold)]" : ""}`}
                onClick={closeDesktopLocations}
              >
                Locations
                <span className="text-white/60 text-xs">▾</span>
              </Link>

              <div className={`invisible absolute left-1/2 -translate-x-1/2 top-full pt-4 opacity-0 transition-all duration-300 ${
                desktopLocationsDismissed
                  ? ""
                  : "group-hover:visible group-hover:opacity-100 group-focus-within:visible group-focus-within:opacity-100"
              }`}>
                <div className="w-[260px] rounded-xl border border-white/10 bg-black/95 backdrop-blur-xl p-3 shadow-[0_20px_60px_rgba(0,0,0,0.8)]">
                  <Link
                    href="/locations"
                    className="block rounded-lg px-3 py-3 text-sm font-semibold text-white hover:bg-white/5 transition-colors"
                    onClick={closeDesktopLocations}
                  >
                    View All Locations →
                  </Link>
                  <div className="my-2 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
                  <div className="max-h-64 overflow-y-auto space-y-0.5 pr-1" style={{ scrollbarWidth: "thin", scrollbarColor: "rgba(255,255,255,0.15) transparent" }}>
                    {LOCATIONS_NAV.cities.map((c) => (
                      <Link
                        key={c.href}
                        href={c.href}
                        className="block rounded-lg px-3 py-2 text-sm text-white/70 hover:bg-white/5 hover:text-white transition-colors"
                        onClick={closeDesktopLocations}
                      >
                        {c.label}
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <Link href="/science" className={`${navLinkClass} ${isActive("/science") ? "text-[var(--zivel-gold)]" : ""}`}>
              Science
            </Link>
            {!isBrecksville && <Link href="/blog" className={`${navLinkClass} ${isActive("/blog") ? "text-[var(--zivel-gold)]" : ""}`}>
              Blog
            </Link>}
            <Link href="/press" className={`${navLinkClass} ${isActive("/press") ? "text-[var(--zivel-gold)]" : ""}`}>
              Press
            </Link>
            <a href="https://www.zivelfranchise.com" target="_blank" rel="noopener noreferrer" className={navLinkClass}>
              Franchise
            </a>

            <div className="flex items-center gap-3 ml-2">
              <Link
                href="/locations"
                className="rounded-none border border-white/20 bg-transparent px-4 py-2.5 text-xs font-medium tracking-wider uppercase text-white hover:border-[var(--zivel-gold)] hover:text-[var(--zivel-gold)] transition-all duration-300"
              >
                Find a Location
              </Link>
              {!bookingDisabled && <a
                href={bookingAction.href}
                target={bookingAction.external ? "_blank" : undefined}
                rel={bookingAction.external ? "noopener noreferrer" : undefined}
                className="rounded-none bg-[var(--zivel-gold)] px-4 py-2.5 text-xs font-medium tracking-wider uppercase text-black hover:bg-[var(--zivel-gold-light)] transition-all duration-300"
              >
                {bookingAction.label}
              </a>}
            </div>
          </nav>

          <div className="flex items-center gap-2 lg:hidden">
            <button
              ref={menuToggleRef}
              className="border border-white/20 bg-transparent px-3 py-2 text-xs font-medium tracking-wider uppercase text-white hover:border-[var(--zivel-gold)] transition-all duration-300"
              onClick={() => setMobileOpen((v) => !v)}
              aria-label={mobileOpen ? "Close navigation menu" : "Open navigation menu"}
              aria-expanded={mobileOpen}
              aria-controls="mobile-nav-panel"
            >
              {mobileOpen ? "Close" : "Menu"}
            </button>
          </div>
        </div>

        {mobileOpen ? (
          <div id="mobile-nav-panel" className="lg:hidden pb-6 pt-2">
            <div
              className="space-y-1 rounded-xl border border-white/10 bg-black/95 backdrop-blur-xl p-4 overflow-y-auto"
              style={{ maxHeight: "calc(100dvh - 5rem)" }}
            >
              <button
                className="flex w-full items-center justify-between px-3 py-3 text-sm font-medium tracking-wide uppercase text-white hover:text-[var(--zivel-gold)] transition-colors"
                onClick={() => setMobileServicesOpen((v) => !v)}
                aria-expanded={mobileServicesOpen}
                aria-controls="mobile-services-panel"
                aria-label={mobileServicesOpen ? "Collapse services menu" : "Expand services menu"}
              >
                <span>Services</span>
                <span className="text-white/60" aria-hidden="true">{mobileServicesOpen ? "−" : "+"}</span>
              </button>

              {mobileServicesOpen ? (
                <div id="mobile-services-panel" className="space-y-1 px-2 pb-2">
                  <Link
                    href="/services"
                    className="block px-3 py-2 text-sm text-white/70 hover:text-[var(--zivel-gold)] transition-colors"
                    onClick={() => setMobileOpen(false)}
                  >
                    View All Services →
                  </Link>
                  {serviceLinks.map((item) => (
                    <Link
                      key={item.href}
                      href={item.href}
                      className="block px-3 py-2 text-sm text-white/60 hover:text-white transition-colors"
                      onClick={() => setMobileOpen(false)}
                    >
                      {item.label}
                    </Link>
                  ))}
                </div>
              ) : null}

              <button
                className="flex w-full items-center justify-between px-3 py-3 text-sm font-medium tracking-wide uppercase text-white hover:text-[var(--zivel-gold)] transition-colors"
                onClick={() => setMobilePathwaysOpen((v) => !v)}
                aria-expanded={mobilePathwaysOpen}
                aria-controls="mobile-pathways-panel"
                aria-label={mobilePathwaysOpen ? "Collapse pathways menu" : "Expand pathways menu"}
              >
                <span>Pathways</span>
                <span className="text-white/60" aria-hidden="true">{mobilePathwaysOpen ? "−" : "+"}</span>
              </button>

              {mobilePathwaysOpen ? (
                <div id="mobile-pathways-panel" className="space-y-1 px-2 pb-2">
                  <Link
                    href="/pathways"
                    className="block px-3 py-2 text-sm text-white/70 hover:text-[var(--zivel-gold)] transition-colors"
                    onClick={() => setMobileOpen(false)}
                  >
                    View All Pathways →
                  </Link>
                  {pathwayLinks.map((item) => (
                    <Link
                      key={item.href}
                      href={item.href}
                      className="block px-3 py-2 text-sm text-white/60 hover:text-white transition-colors"
                      onClick={() => setMobileOpen(false)}
                    >
                      {item.label}
                    </Link>
                  ))}
                </div>
              ) : null}

              <button
                className="flex w-full items-center justify-between px-3 py-3 text-sm font-medium tracking-wide uppercase text-white hover:text-[var(--zivel-gold)] transition-colors"
                onClick={() => setMobileLocationsOpen((v) => !v)}
                aria-expanded={mobileLocationsOpen}
                aria-controls="mobile-locations-panel"
                aria-label={mobileLocationsOpen ? "Collapse locations menu" : "Expand locations menu"}
              >
                <span>Locations</span>
                <span className="text-white/60" aria-hidden="true">{mobileLocationsOpen ? "−" : "+"}</span>
              </button>

              {mobileLocationsOpen && (
                <div id="mobile-locations-panel" className="space-y-1 px-2 pb-2">
                  <Link
                    href="/locations"
                    className="block px-3 py-2 text-sm text-white/70 hover:text-[var(--zivel-gold)] transition-colors"
                    onClick={() => setMobileOpen(false)}
                  >
                    Browse All Locations →
                  </Link>
                  {LOCATIONS_NAV.cities.map((c) => (
                    <Link
                      key={c.href}
                      href={c.href}
                      className="block px-3 py-2 text-sm text-white/60 hover:text-white transition-colors"
                      onClick={() => setMobileOpen(false)}
                    >
                      {c.label}
                    </Link>
                  ))}
                </div>
              )}

              <div className="h-px bg-gradient-to-r from-transparent via-white/10 to-transparent my-2" />

              <Link
                href="/science"
                className="block px-3 py-3 text-sm font-medium tracking-wide uppercase text-white hover:text-[var(--zivel-gold)] transition-colors"
                onClick={() => setMobileOpen(false)}
              >
                Science
              </Link>
              {!isBrecksville && <Link
                href="/blog"
                className="block px-3 py-3 text-sm font-medium tracking-wide uppercase text-white hover:text-[var(--zivel-gold)] transition-colors"
                onClick={() => setMobileOpen(false)}
              >
                Blog
              </Link>}
              <Link
                href="/press"
                className="block px-3 py-3 text-sm font-medium tracking-wide uppercase text-white hover:text-[var(--zivel-gold)] transition-colors"
                onClick={() => setMobileOpen(false)}
              >
                Press
              </Link>
              <a
                href="https://www.zivelfranchise.com"
                target="_blank"
                rel="noopener noreferrer"
                className="block px-3 py-3 text-sm font-medium tracking-wide uppercase text-white hover:text-[var(--zivel-gold)] transition-colors"
                onClick={() => setMobileOpen(false)}
              >
                Franchise
              </a>

              <div className="grid gap-2 pt-3">
                <Link
                  href="/locations"
                  className="border border-white/20 bg-transparent px-4 py-3 text-xs font-medium tracking-wider uppercase text-white text-center hover:border-[var(--zivel-gold)] transition-all duration-300"
                  onClick={() => setMobileOpen(false)}
                >
                  Find a Location
                </Link>
                {!bookingDisabled && <a
                  href={bookingAction.href}
                  target={bookingAction.external ? "_blank" : undefined}
                  rel={bookingAction.external ? "noopener noreferrer" : undefined}
                  className="bg-[var(--zivel-gold)] px-4 py-3 text-xs font-medium tracking-wider uppercase text-black text-center hover:bg-[var(--zivel-gold-light)] transition-all duration-300"
                  onClick={() => setMobileOpen(false)}
                >
                  {bookingAction.label}
                </a>}
              </div>
            </div>
          </div>
        ) : null}
      </div>
    </header>
  );
}
